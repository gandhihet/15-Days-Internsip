package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText et1;
    EditText et2;
    Button addbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1 = findViewById(R.id.et1);
        et2 = findViewById(R.id.et2);
        addbtn = findViewById(R.id.addbtn);
        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //convert text into string
                String num1, num2;
                num1=et1.getText().toString();
                num2=et2.getText().toString();
                //Convert editText into Integer
                int a= Integer.parseInt(num1);
                int b=Integer.parseInt(num2);
                int sum= a+b;
                Toast.makeText(MainActivity.this, "Sum is:" +sum,Toast.LENGTH_LONG).show();
            }
        });
    }
}